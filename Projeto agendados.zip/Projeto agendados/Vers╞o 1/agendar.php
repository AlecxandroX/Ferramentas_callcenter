<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $protocolo = $_POST["protocolo"];
    $dataHora = $_POST["dataHora"];

    $sql = "INSERT INTO agendamentos (protocolo, dataHora) VALUES ('$protocolo', '$dataHora')";

    if ($conn->query($sql) === TRUE) {
        echo "Agendamento realizado com sucesso!";
    } else {
        echo "Erro ao agendar: " . $conn->error;
    }

    $conn->close();
}
?>
