<?php
include("config.php");

date_default_timezone_set("America/Sao_Paulo"); 

$currentDateTime = date("Y-m-d H:i:s");

$sql = "SELECT * FROM agendamentos WHERE dataHora <= '$currentDateTime'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $protocolo = $row["protocolo"];
        $dataHora = $row["dataHora"];

        echo "É hora do agendamento: Protocolo $protocolo às $dataHora";

        
    }
} else {
    echo "Nenhum agendamento no momento.";
}

$conn->close();
?>
