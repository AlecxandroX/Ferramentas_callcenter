<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $protocolo = $_POST["protocolo"];
    $dataHora = $_POST["dataHora"];

    // Abra o arquivo para escrita (ou crie-o se não existir)
    $arquivo = fopen("agendamentos.txt", "a");

    if ($arquivo) {
        // Escreva os dados no arquivo
        fwrite($arquivo, "Protocolo: $protocolo, Data e Hora: $dataHora" . PHP_EOL);
        fclose($arquivo);
        echo "Agendamento realizado com sucesso!";
    } else {
        echo "Erro ao abrir o arquivo para escrita.";
    }
}
?>
