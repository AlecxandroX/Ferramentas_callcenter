<?php
$servername = "ws4.altcloud.net.br";  
$username = "seu_usuario";  // Nome de usuário do banco de dados
$password = "sua_senha";    // Senha do banco de dados
$dbname = "seu_banco_de_dados";  // Nome do banco de dados
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}
?>
